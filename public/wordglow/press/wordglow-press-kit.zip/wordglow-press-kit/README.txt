WordGlow: Daily Word Puzzle
Guess the daily word in 6 tries and learn what it means.

WordGlow is a free word puzzle for Android where every answer teaches you its meaning.

WordGlow is a guess-the-word game: you have 6 tries to find a hidden word, and coloured tiles show which letters are right. When the round ends, the game shows the word's part of speech and meaning and saves it to a personal "My Words" list.

It was built by a solo developer who liked daily word games but noticed they taught nothing: you guess an unusual word and forget it a minute later. WordGlow keeps the familiar format and adds the meaning, more word lengths and unlimited play.

Alongside the Android app there is a free browser version with unlimited 5-letter puzzles, plus a solver and an unscrambler that also show word meanings.

Features
- A daily word shared by all players, 6 tries
- Four levels: 4, 5, 6 and 7-letter words, 6,000 words that never repeat
- The meaning of every answer (from WordNet 3.0), saved to "My Words"
- Beat the Clock: 90 seconds per word
- Points, 10 ranks, daily streaks and shareable score cards
- Works offline, no account

Fact sheet
Developer: Arshad Iqbal (AT Web Tech)
Publisher on Google Play: A2Z AIRPORT PARKING LTD
Released: November 2026
Platforms: Android (Google Play); free browser version
Price: Free, with ads. No in-app purchases.
Genre: Word puzzle
Languages: English
Built with: Flutter

Google Play: https://play.google.com/store/apps/details?id=com.atwebtech.wordglow
Website: https://atwebtech.us/wordglow/
Press kit: https://atwebtech.us/wordglow/press/
Contact: Arshad Iqbal, arshadiqbal.d@gmail.com
