Halcyon: Calm Puzzle Games
Eighty calm puzzle games in one offline Android app.

Halcyon is a free Android app with about eighty brain games in one calm place: no account, no timers, offline.

Halcyon is a collection of about eighty brain games and puzzles in a single Android app, presented in a calm 3D glass style. Each game is made for touch, and there are no countdown timers, lives or sign-ups.

It covers logic puzzles (Sudoku, Sudoku X, Killer Sudoku, Kakuro, Futoshiki, Nonogram, Queens, Star Battle), spatial puzzles (Tangram, Jigsaw, Flow, Sokoban, Bridges), matching games (Mahjong Solitaire, Triple Tiles, Gem Swap), board games against the app (Chess, Checkers, Reversi) and card games (Klondike, Spider).

The idea is one quiet app in place of a folder of separate puzzle games.

Features
- About eighty games in one app
- Logic, spatial, matching, board and card games
- No account, no timers, no lives
- Works offline
- Easy, medium and hard settings in many games
- A daily featured puzzle

Fact sheet
Developer: Arshad Iqbal (AT Web Tech)
Publisher on Google Play: A2Z AIRPORT PARKING LTD
Released: 2026
Platforms: Android (Google Play). iPhone version planned.
Price: Free, with ads.
Genre: Puzzle collection
Languages: English

Google Play: https://play.google.com/store/apps/details?id=com.halcyon.puzzles.halcyon
Website: https://atwebtech.us/halcyon/
Press kit: https://atwebtech.us/halcyon/press/
Contact: Arshad Iqbal, arshadiqbal.d@gmail.com
